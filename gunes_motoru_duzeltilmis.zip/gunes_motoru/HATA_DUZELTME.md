# Hata düzeltme açıklaması

## İlk sorunun teşhisi ve sınırı

Özgün dosya, 3D kütüphanesi indirmeden Canvas 2D üzerinde çizim yapıyordu. Harici CDN’nin yüklenememesi ilk sorun için açıklama değildir. iPhone’da ChatGPT dosya bağlantısıyla açılınca çalışmaması, dosya önizleyicisinin JavaScript’i çalıştırmamasıyla uyumludur. İlk arızanın yaşandığı fiziksel iPhone ve önizleyiciye erişilmediği için bu neden kesinleşmiş değildir.

JavaScript’i engelleyen bir önizleyiciyi HTML içinden aşmak mümkün değildir. Çözüm paketi `npm run dev` ile normal bir web sayfası olarak çalışır; HTTPS yayımlama adımları README’dedir. Statik açılış metni ve `<noscript>` mesajı, JavaScript hiç çalışmazsa da kullanıcıya Safari/Chrome üzerinden açma yolunu anlatır.

## Kodda giderilen sorunlar

| Durum | Önceki davranış | Düzeltilen davranış |
| --- | --- | --- |
| Eski Canvas API’si | `ctx.roundRect` doğrudan çağrılıyordu; API olmayan motorda ilk çizim hata verebilirdi. | Yuvarlak etiketler temel çizgi ve eğri komutlarıyla çizilir. `roundRect` gerekmez. |
| Başlatma/çizim hatası | Context alınamaması, çizim veya yükleme hatası kullanıcıya açıklanmıyordu. | Canvas desteği kontrol edilir; script indirme, çalışma zamanı ve çizim hataları ekranda anlaşılır mesaj ve yeniden deneme düğmesi gösterir, konsola yazılır. Başlatma zaman aşımı da ele alınır. |
| İki parmakla yakınlaştırma | İlk pinch mesafesi hareketten sonra kuruluyordu; hareketin başlangıcı kaybolabiliyordu. Her yeni pointer dokunma durumunu sıfırlıyordu. | Önceki/yeni parmak mesafesi kullanılır; mesafe sınırlandırılır, birbirine değen parmaklar sonsuz/bozuk yakınlaştırma oluşturmaz. |
| Dokunma ile pinch ayrımı | İptal olayları normal bırakma işlemiyle aynı yola giriyordu; çoklu dokunma durumu bütün hareket boyunca korunmuyordu. | İki parmak kullanılan bir hareket parça seçimine dönüşmez. `pointercancel` ve capture kaybı seçim üretmeden temizlenir. |
| Parça seçimi | Yalnız parça merkezine yakınlık dikkate alınıyordu; yakındaki örtülü parça seçilebilirdi. | Görünen etiket alanları ve ters çizim sırasındaki görünür yüzeyler hit testine girer. |
| WebKit yeniden boyutlandırma | Aynı Canvas boyutlarını tekrar atamak bile bitmap’i temizliyordu; hazır işareti çizimden önce doğru kalabiliyordu. | Boyutlar yalnız değişince atanır; temizlenen tuval yeni çizime kadar hazır sayılmaz. WebKit piksel testiyle doğrulandı. |
| Pil tüketimi ve animasyon | Pervane dururken bile her kare çiziliyordu; hız kare sayısına bağlıydı. | Duran model yalnız görünüm/etkileşim değişince çizilir. Animasyon geçen zamana bağlıdır; gizli sekmede çizim durur. |
| Erişilebilirlik | Canvas klavye ile kullanılamıyordu, sayfa zoom’u viewport ile kapatılmıştı. | Klavye kontrolleri, erişilebilir düğme adları ve `aria-pressed` durumları eklendi; sayfa zoom engeli kaldırıldı. Canvas içinde `touch-action:none` model hareketini yönetir. |

Güncel tarayıcılar için ResizeObserver kullanılır; olmayan ortamlarda pencere yeniden boyutlandırma olayı temel uyumluluğu sürdürür. Retina çizimi en fazla 2 piksel oranıyla sınırlıdır.

## Yapı ve içerik

Mevcut Canvas geometrisi korundu. Bakımı kolaylaştırmak için sayfa, stil ve model `index.html`, `styles.css`, `model.js` dosyalarına ayrıldı. Çalışma zamanında üçüncü taraf bağımlılığı yoktur. Node.js sunucusu ve statik build betiği de yalnız standart kütüphaneyi kullanır. Playwright yalnız test bağımlılığıdır.

Mobil ekranlarda etiket çakışmaları yakın boş satırlara taşınarak giderildi. Güneş paneli yüzeyi küçük hücre ve arka plan karolarına ayrıldı; ortalama derinlik sıralamasının hücreleri örtmesi önlendi.

Maketin 11 parça grubu korunur: taban, panel ve stand, şarj kartı, korumalı 18650 ve yuva, DC-DC, INA219, ESP32, OLED, mekanik anahtar, bobinli motor ve dört kanatlı pervane. Parça açıklamalarına panelin açık devre gerilimi, şarj kartı uyumu, pil koruması/şarj ayrımı ve örnek DC-DC giriş/çıkış aralıkları eklendi. Kabloların kesin şema olmadığı sayfada sürekli görünür.

## Doğrulama

Tarayıcı testleri çizimin gerçekten oluşmasını, dokunma ve fareyle döndürmeyi, pinch zoom’u, canvas üzerinden parça seçimini, düğmeleri, animasyonu, dar ekranı ve hata durumlarını sınar. `roundRect` desteğinin yokluğu, alınamayan Canvas context’i, çizim hatası, yüklenemeyen script ve kapalı JavaScript ayrı senaryolardır. Android Chromium profilinde CDP üzerinden gerçek çoklu dokunma olayları da kullanılır.

Çalıştırılan ortamlar, sonuç sayıları ve fiziksel cihaz/HTTPS doğrulama sınırları için [MOBIL_TEST_OZETI.md](MOBIL_TEST_OZETI.md) esas alınmalıdır. WebKit iPhone emülasyonu, fiziksel iPhone Safari doğrulaması olarak raporlanmamalıdır.
