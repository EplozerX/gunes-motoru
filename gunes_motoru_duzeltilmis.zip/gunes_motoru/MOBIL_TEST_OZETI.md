# Mobil ve tarayıcı test özeti

Tarih: 15 Kasım 2026. Kaynak: bu paketteki son `index.html`, `styles.css`, `model.js`.

## Otomatik regresyon sonucu

**34 başarılı, 2 kasıtlı atlama, 0 başarısız** (son tam çalışma: 46,7 saniye).

| Profil | Motor / sürüm | CSS viewport | Sonuç |
| --- | --- | --- | --- |
| Masaüstü Chrome profili | Chromium 156.0.8078.79 | 1440 × 1000 | 11 başarılı + 1 atlama |
| Android / Pixel 7 profili | Chromium 156.0.8078.79 | 412 × 839 | 12 başarılı |
| iPhone 13 profili | Playwright WebKit 26.0 | 390 × 664 | 11 başarılı + 1 atlama |

İki atlama, yalnız Chromium CDP ile yapılabilen Android yerel çoklu dokunma testinin diğer profillerde çalıştırılmamasıdır. Tüm profillerde ayrıca PointerEvent pinch testi çalışır. Profillerin piksel oranları farklıdır; Retina çizim oranı uygulamada 2 ile sınırlıdır. 320 piksel genişliğe yeniden boyutlandırma da test edilir.

Çalıştırılan komut:

```sh
PLAYWRIGHT_SKIP_VALIDATE_HOST_REQUIREMENTS=1 \
PW_CHROMIUM_EXECUTABLE_PATH=/usr/bin/chromium npm test
```

Playwright 1.56.1 kullanıldı. Bu çalışma ortamında WebKit’in eksik sistem kütüphaneleri resmi Debian paketlerinden SHA-256 doğrulamasıyla kullanıcı klasörüne çıkarıldı ve tarayıcı önbelleğine bağlandı. Sistem kurulumu değiştirilmedi. `PLAYWRIGHT_SKIP_VALIDATE_HOST_REQUIREMENTS=1`, kullanıcı klasöründeki kütüphaneleri görmeyen sistem bağımlılık ön kontrolünü atlamak için kullanıldı; gerçek WebKit başlatıldı ve çizim/etkileşim testleri çalıştı. Normal kurulumda bu değişken gerekli değildir.

## Doğrulanan davranışlar

- Canvas piksellerinin gerçekten çok renkli model çizmesi; 11 parça düğmesi, yatay sayfa taşması ve üçüncü taraf ağ isteği olmaması.
- Fare/dokunma sürüklemesiyle yaw ve pitch değişmesi, canvas etiketi üzerinden panel seçimi ve Türkçe bilginin değişmesi.
- İki parmakla zoom; pinch ve iptal edilen hareketin parça seçmemesi; parmaklar birleştiğinde sonlu ve sınırlı yakınlaştırma.
- Android Chromium’da CDP aracılığıyla tarayıcının yerel giriş sistemine eşzamanlı iki dokunma noktası gönderilmesi.
- Yakınlaştırma, uzaklaştırma, sıfırlama, kabloları gösterme/gizleme ve animasyonun başlatılıp durması.
- Boşta çizim sayısının sabit kalması; giriş/animasyonda yeniden çizilmesi ve durdurulduğunda tekrar sabitlenmesi.
- `roundRect` olmayan Canvas, alınamayan 2D context, çizim sırasında hata, indirilemeyen `model.js` ve JavaScript kapalı durumlarında açıklayıcı geri dönüş.

WebKit testi bir ilk-açılış yarışını yakaladı: ResizeObserver aynı tuval boyutunu atayarak çizimi siliyordu. Gereksiz boyut atamasını önleme ve yeni çizime kadar `data-ready=false` düzeltmesinden sonra son tam test geçti.

## HTTPS kontrolü

`npm run test:https` karşılığı, son `dist/` çıktısında üç profilde de **başarılı** çalıştı. Yerel Node HTTPS sunucusu ve bir günlük geçici, kendinden imzalı sertifika kullanıldı. Yalnız bu test bağlamında sertifika doğrulaması atlandı; sertifika/key dosyaları test sonunda silindi.

HTTPS belge ve yerel varlıkların açılması, boş olmayan Canvas çizimi, canvas üstünden parça seçimi, zoom ve JavaScript hatası olmaması doğrulandı. Sonuç: [verification/https-smoke.json](verification/https-smoke.json).

**Bu kontrol internette yayımlanmış, genel güven zincirine sahip HTTPS adresi doğrulaması değildir. Canlı site yayımlanmadı.** Kurulum ve GitHub Pages/Netlify/Vercel HTTPS yayımlama adımları [README.md](README.md) içindedir.

## Kapsam sınırları ve elle son kontrol

Fiziksel iPhone Safari, fiziksel Android Chrome ve ilk hatanın görüldüğü ChatGPT/Dosyalar önizleyicisi kullanılmadı. Gerçek tarayıcı motorlarında cihaz emülasyonu kullanıldı; bu nedenle özgün iPhone sorununun kesin kök nedeni olarak önizleyici yasağı iddia edilmez. JavaScript kapalı senaryosu bu açıklamayla uyumludur ve geri dönüş metni test edildi.

Canlı HTTPS’ye yükledikten sonra fiziksel telefonlarda adresi Safari/Chrome’da açın; bir parmakla döndürmeyi, iki parmakla zoom’u, parça seçimini, bütün düğmeleri ve ekranı yatay çevirmeyi deneyin. İlk telefonun işletim sistemi/tarayıcı sürümü de kaydedilmelidir. Test edilen model elektrik devresi doğrulaması değildir.

## Kanıt dosyaları

- [Tam Playwright HTML raporu](playwright-report/index.html)
- [Masaüstü ekranı](screenshots/desktop.png)
- [Android profili ekranı](screenshots/android.png)
- [iPhone profili ekranı](screenshots/iphone.png)
- [Test kaynağı](tests/model.spec.mjs)
