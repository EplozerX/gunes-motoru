# Güneş enerjili el yapımı motor — interaktif 3D maket

11. sınıf fizik projesinin yaklaşık 45 × 30 cm taban üzerindeki yerleşimini gösterir. Canvas 2D ile 3D projeksiyon çizilir; Three.js, CDN, hesap veya internetten yüklenen varlık gerekmez. Bu bir resim değildir: model döndürülür, yakınlaştırılır ve parçalar seçilir.

## Bilgisayarda çalıştırma

Node.js 20 veya daha yenisini kurun. ZIP’i çıkarıp bu klasörde terminal açın:

```sh
npm run dev
```

Tarayıcıda `http://localhost:8000` açın. Geliştirme sunucusu bağımlılık kullanmadığı için bu adımda `npm install` gerekmez. Durdurmak için `Ctrl+C` kullanın.

Telefon ve bilgisayar aynı yerel ağdaysa telefonda `http://BILGISAYARIN_YEREL_IP_ADRESI:8000` açın. Örneğin adres `http://192.168.1.25:8000` olabilir; bilgisayarın güvenlik duvarı bağlantıya izin vermelidir. **Telefondaki `localhost` bilgisayarı göstermez.** Yerel ağ dışından açmak için aşağıdaki HTTPS yayımlama seçeneklerinden birini kullanın.

ChatGPT dosya önizlemesi veya iPhone Dosyalar önizlemesi JavaScript’i engelleyebilir. Böyle bir önizleme interaktif modeli çalıştıramaz; web sayfasını Safari veya Chrome’da açın. Yalnız `index.html` dosyasını taşımayın: `model.js` ve `styles.css` aynı klasörde kalmalıdır.

## Kontroller

- Tek parmakla veya fareyle sürükleme: modeli döndürme.
- İki parmakla sıkıştırma/açma: yakınlaştırma. Fare tekerleği de kullanılabilir.
- Parçanın veya etiketinin üzerine dokunma: Türkçe parça bilgisini seçme. Alttaki parça düğmeleri de aynı işi yapar.
- `+`, `−`, `⟲`, `⌁`: yakınlaştırma, uzaklaştırma, görünümü sıfırlama ve temsili kabloları gösterme/gizleme.
- **Pervaneyi döndür/durdur**: yalnızca görsel animasyon; fiziksel donanıma komut göndermez.
- Canvas klavye odağındayken ok tuşları döndürür, `+`/`−` yakınlaştırır, `Home` görünümü sıfırlar.

## HTTPS üzerinde yayımlama

Önce statik çıktıyı oluşturun; bu komut için de bağımlılık kurulumu gerekmez:

```sh
npm run build
```

`dist/` içinde yalnızca `index.html`, `model.js` ve `styles.css` oluşur. Üçünü birlikte yayımlayın. Göreli dosya yolları sayesinde proje alt dizininde de çalışır.

### GitHub Pages

1. GitHub’da yeni bir depo oluşturun.
2. **Add file → Upload files** ile `dist/` klasörünün içindeki üç dosyayı deponun köküne yükleyip `main` dalına commit edin. `dist` klasörünü üst klasör olarak yüklemeyin.
3. **Settings → Pages → Build and deployment** bölümünde **Source: Deploy from a branch** seçin.
4. **Branch: main**, klasör **/(root)** seçip **Save** deyin.
5. Yayımlama tamamlandığında Pages bölümünün verdiği `https://…github.io/…/` adresini telefonda Safari/Chrome ile açın.

### Netlify

Netlify hesabınızda **Add new site/project → Deploy manually** seçeneğine `dist/` klasörünü bırakın. Yayımlanan `https://….netlify.app` adresini kullanın. Git deposu bağlayacaksanız build komutu `npm run build`, publish directory `dist` olmalıdır.

### Vercel

Kaynak klasörü bir Git deposuna yükleyip Vercel’de **Add New → Project** ile içe aktarın. **Framework Preset: Other**, **Build Command: npm run build**, **Output Directory: dist**, **Install Command: npm ci** kullanın. Deploy tamamlanınca verilen HTTPS adresini açın.

Bu teslim yerel kaynak ve yayımlanmaya hazır `dist/` çıktısıdır; canlı bir site yayımlanmadı. Yerel HTTPS testinin kapsamı test özetindedir.

## Otomatik testler

İlk kurulum:

```sh
npm ci
npx playwright install chromium webkit
npm test
```

Linux’ta Playwright eksik sistem kütüphaneleri bildirirse kendi işletim sisteminizin kurulum adımlarını izleyin veya uygun yetkiyle `npx playwright install --with-deps chromium webkit` çalıştırın.

Yerel HTTPS açılış testi (Node.js yanında OpenSSL gerekir):

```sh
npm run test:https
```

Bu test geçici, kendinden imzalı sertifika üretir; yalnız test tarayıcısında bu sertifikanın doğrulamasını atlar. Canlı HTTPS yayımlaması veya fiziksel telefon testi değildir. Sonucu `verification/https-smoke.json` dosyasına yazar; sertifikayı siler.

Yalnız mobil profiller:

```sh
npm run test:mobile
```

Mevcut bir Chromium kullanmak için örnek:

```sh
PW_CHROMIUM_EXECUTABLE_PATH=/usr/bin/chromium npm test
```

Testler kendi yerel sunucusunu açar. Masaüstü Chromium, Android Chromium emülasyonu ve iPhone WebKit emülasyonunu kullanır. Emülasyon fiziksel iPhone Safari veya Android Chrome testiyle aynı değildir. Sonuçlar, ortam ve sınırlar: [Mobil test özeti](MOBIL_TEST_OZETI.md). HTML raporu testten sonra `playwright-report/index.html` altında bulunur.

## Dosyalar

- `index.html`: sayfa, açılış durumu ve hata/JavaScript kapalı mesajları.
- `styles.css`: masaüstü ve telefon görünümü.
- `model.js`: geometri, projeksiyon, çizim, hit testi ve etkileşimler.
- `scripts/server.mjs`, `scripts/build.mjs`: bağımlılıksız sunucu ve statik paketleme.
- `scripts/https-smoke.mjs`: üç tarayıcı profili için yerel HTTPS açılış testi.
- `tests/`, `playwright.config.mjs`: tarayıcı regresyon testleri.
- [Hata düzeltme açıklaması](HATA_DUZELTME.md), [özgün görev](CODEX_GOREV.md).

## Elektrik ve pil hakkında

**Bu model fiziksel yerleşimi anlatır; kesin devre şeması veya pin bağlantı talimatı değildir.** Kabloların renkleri ve çizgileri temsilidir. INA219 tek başına kesin pil yüzdesi ölçmez; OLED’deki `%78` örnek veridir.

Örnek 1S Li-ion besleme aralığı yaklaşık **3,0–4,2 V** olarak açıklanır. Uyumlu bir boost ile 5 V yalnızca 5 V girişi kabul eden ESP32 geliştirme kartına verilebilir. 3V3 hattı için pilin bütün aralığını kapsayan sabit 3,3 V buck-boost seçimi gerekir. Gerçek giriş aralığı, düşük pil kesmesi, çıkış akımı ve motorun kalkış/kilitlenme akımı seçilen ürünlerle doğrulanmalıdır. Motor GPIO’dan beslenmez.

6 V nominal panelin açık devre gerilimi daha yüksek olabilir. Panel, 1S pil ve şarj kartı uyumu; şarj sırasında çalışılacaksa güç yolu/yük paylaşımı desteği kontrol edilmelidir. Korumalı 18650’nin koruması şarj kontrolünün yerini tutmaz. Uyumlu yuva kullanın; kısa devre yapmayın, hücreye doğrudan lehim yapmayın ve hasarlı hücre kullanmayın. Gerçek montajda ürün datasheet’lerini ve öğretmen gözetimini esas alın.
