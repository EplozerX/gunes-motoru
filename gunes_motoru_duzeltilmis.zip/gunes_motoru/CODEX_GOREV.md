# Codex görevi: 11. sınıf fizik projesi için mobil uyumlu 3D model

## Sorun
Mevcut `index.html` dosyası bir güneş enerjili, OLED ekranlı, ESP32 kontrollü, elde sarılan bobin motorlu fizik projesinin döndürülebilir 3D konseptidir. Kullanıcı iPhone üzerinden ChatGPT dosya bağlantısıyla açtığında çalışmadığını bildiriyor. Asıl nedeni belirle ve çöz. Mevcut dosya harici 3D kütüphanesine bağlı olmayan, Canvas 2D üzerinde elle çizilmiş 3D projeksiyon içeriyor. Dosya önizleme araçları JavaScript'i çalıştırmayabilir; sadece kodu değil gerçek Safari/Chrome üzerinde HTTPS sayfa olarak açmayı da test et.

## İstenen sonuç
- Telefon ekranında parmakla sürükleyince 3D model dönebilsin, iki parmakla pinch zoom yapılabilsin, dokunulan parça seçilebilsin.
- Yakınlaştırma, sıfırlama, kabloları göster/gizle ve pervaneyi başlat/durdur tuşları çalışsın.
- 45 x 30 cm civarı maket tabanı; üstünde güneş paneli ve standı, şarj kontrol kartı, korumalı 18650 batarya ve yuva, gerekli DC-DC düzenleyici (uygun voltaj aralıklarıyla), INA219 akım/voltaj sensörü, ESP32, 0.96 inç OLED, mekanik ON/OFF anahtarı, elle sarılmış bakır bobinli mıknatıslı DC motor, 4 kanatlı hafif pervane, destekler ve bağlantılar gösterilsin.
- Parça bilgileri Türkçe olsun. Fiziksel yerleşim ile elektriksel olarak kesin devre şemasını karıştırma. Batarya ve şarj kartı uyumu, 18650 güvenliği ve gerçek bağlantıların seçilecek ürünün pinlerine bağlı olduğu uyarısını göster.
- Yüklenme hatası olursa ekranda anlaşılır mesaj göster; boş ekran bırakma. Hataları konsola yaz.
- iPhone Safari, Chrome Android ve masaüstü Chrome'da doğrula; mümkünse Playwright ile viewport ve dokunma etkileşimlerini test et. Performansı makul tut.
- Sorun dosya önizleyicisinin JS yasağıysa, `npm run dev` ile açılan yerel site veya GitHub Pages/Vercel/Netlify ile HTTPS üzerinde çalışan bir web sayfası olarak sun; açık kurulum/yayınlama adımları ver.
- Teslim: çalışan kaynak dosyaları, çalıştırma komutları, mobil test özeti, hata düzeltme açıklaması. 3D model parmakla gerçekten interaktif olmalı, sadece resim olmasın.

## Tercih
Önce mevcut HTML/Canvas kodunu onarmaya çalış. Gerekliyse Vite + Three.js'e geçebilirsin. Kodun anlaşılır ve bakım yapılabilir olması önemli. Harici üçüncü taraf CDN bağlantısına mecbur kalmasın.
