import { test, expect } from 'playwright/test';
import { mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const state = page => page.locator('#view').evaluate(canvas => ({
  yaw: Number(canvas.dataset.yaw),
  pitch: Number(canvas.dataset.pitch),
  distance: Number(canvas.dataset.distance),
  spin: Number(canvas.dataset.spin),
  selected: canvas.dataset.selected,
  wires: canvas.dataset.wires,
  running: canvas.dataset.running,
}));

async function openModel(page) {
  await page.goto('/');
  await expect(page.locator('#view')).toHaveAttribute('data-ready', 'true');
  await expect(page.locator('#loadStatus')).toBeHidden();
}

async function pointer(page, type, id, x, y, isPrimary = id === 1) {
  await page.locator('#view').dispatchEvent(type, {
    pointerId: id,
    pointerType: 'touch',
    clientX: x,
    clientY: y,
    isPrimary,
    bubbles: true,
    buttons: type === 'pointerup' || type === 'pointercancel' ? 0 : 1,
  });
}

async function gesturePoints(page) {
  const box = await page.locator('#view').boundingBox();
  return { x: box.x + box.width * 0.5, y: box.y + box.height * 0.5 };
}

// Use the actual projected target to exercise the canvas hit test, not the parts list.
async function componentTarget(page, id) {
  return page.locator('#view').evaluate((canvas, id) => {
    const rect = canvas.getBoundingClientRect();
    const target = JSON.parse(canvas.dataset.targets)[id];
    return { x: rect.x+target.x, y: rect.y+target.y };
  }, id);
}

test('loads a rendered, responsive model without browser errors or external requests', async ({ page }, testInfo) => {
  const errors = [];
  const externalRequests = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('request', request => {
    if (!request.url().startsWith('http://127.0.0.1:4173') && !request.url().startsWith(process.env.TEST_BASE_URL || 'http://127.0.0.1:4173')) {
      externalRequests.push(request.url());
    }
  });
  await openModel(page);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  const colors = await page.locator('#view').evaluate(canvas => {
    const pixels = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data;
    const colors = new Set();
    for (let i = 0; i < pixels.length; i += 400) colors.add(`${pixels[i]},${pixels[i+1]},${pixels[i+2]}`);
    return colors.size;
  });
  expect(colors).toBeGreaterThan(20);
  await expect(page.locator('.part')).toHaveCount(11);
  expect(errors).toEqual([]);
  expect(externalRequests).toEqual([]);
  const screenshotName = {
    'desktop-chromium': 'desktop.png',
    'android-chromium': 'android.png',
    'iphone-webkit': 'iphone.png',
  }[testInfo.project.name];
  await mkdir(new URL('../screenshots/', import.meta.url), { recursive: true });
  const screenshot = await page.screenshot({
    fullPage: true,
    path: fileURLToPath(new URL(`../screenshots/${screenshotName}`, import.meta.url)),
  });
  await testInfo.attach('model', { body: screenshot, contentType: 'image/png' });
});

test('canvas drag changes the view and tapping a component selects its Turkish details', async ({ page, isMobile }) => {
  await openModel(page);
  const before = await state(page);
  const { x, y } = await gesturePoints(page);
  if (isMobile) {
    await pointer(page, 'pointerdown', 1, x, y);
    await pointer(page, 'pointermove', 1, x + 65, y + 25);
    await pointer(page, 'pointerup', 1, x + 65, y + 25);
  } else {
    await page.mouse.move(x, y);
    await page.mouse.down();
    await page.mouse.move(x + 65, y + 25, { steps: 8 });
    await page.mouse.up();
  }
  await expect.poll(async () => (await state(page)).yaw).toBeGreaterThan(before.yaw + 0.1);
  await expect.poll(async () => (await state(page)).pitch).toBeGreaterThan(before.pitch + 0.05);
  await page.locator('#reset').click();
  const solar = await componentTarget(page, 'solar');
  if (isMobile) await page.touchscreen.tap(solar.x, solar.y);
  else await page.mouse.click(solar.x, solar.y);
  await expect.poll(async () => (await state(page)).selected).toBe('solar');
  await expect(page.locator('#componentName')).toHaveText('Güneş paneli');
});

test('pinch zoom does not select a part and remains stable when fingers meet', async ({ page }) => {
  await openModel(page);
  const before = await state(page);
  const { x, y } = await gesturePoints(page);
  await pointer(page, 'pointerdown', 1, x - 35, y);
  await pointer(page, 'pointerdown', 2, x + 35, y);
  await pointer(page, 'pointermove', 1, x - 70, y);
  await pointer(page, 'pointermove', 2, x + 70, y);
  await pointer(page, 'pointerup', 2, x + 70, y);
  await pointer(page, 'pointerup', 1, x - 70, y);
  await expect.poll(async () => (await state(page)).distance).toBeLessThan(before.distance);
  expect((await state(page)).selected).toBe(before.selected);
  // A canceled gesture must never become a tap or leave a captured pointer behind.
  await pointer(page, 'pointerdown', 1, x - 1, y);
  await pointer(page, 'pointerdown', 2, x + 1, y);
  await pointer(page, 'pointermove', 2, x - 1, y);
  await pointer(page, 'pointercancel', 2, x - 1, y);
  await pointer(page, 'pointercancel', 1, x - 1, y);
  const after = await state(page);
  expect(Number.isFinite(after.distance)).toBe(true);
  expect(after.distance).toBeGreaterThanOrEqual(420);
  expect(after.distance).toBeLessThanOrEqual(1100);
  expect(after.selected).toBe(before.selected);
});

test('zoom, reset, wire visibility, parts and motor animation work', async ({ page }) => {
  await openModel(page);
  const initial = await state(page);
  await page.locator('#zoomIn').click();
  await expect.poll(async () => (await state(page)).distance).toBeLessThan(initial.distance);
  await page.locator('#zoomOut').click();
  await page.locator('#reset').click();
  await expect.poll(async () => (await state(page)).distance).toBe(initial.distance);
  await page.locator('#wires').click();
  await expect(page.locator('#wires')).toHaveAttribute('aria-pressed', 'false');
  await expect.poll(async () => (await state(page)).wires).toBe('false');
  await page.locator('#wires').click();
  await expect.poll(async () => (await state(page)).wires).toBe('true');
  await page.locator('[data-part="battery"]').click();
  await expect(page.locator('#componentName')).toContainText('18650');
  await page.locator('#motorBtn').click();
  await expect(page.locator('#motorBtn')).toHaveAttribute('aria-pressed', 'true');
  await expect.poll(async () => (await state(page)).spin).not.toBe(initial.spin);
  await page.locator('#motorBtn').click();
  await expect(page.locator('#motorBtn')).toHaveAttribute('aria-pressed', 'false');
  const stopped = await state(page);
  await page.waitForTimeout(200);
  expect((await state(page)).spin).toBe(stopped.spin);
});

test('resizing to a narrow phone preserves a visible usable canvas', async ({ page }) => {
  await openModel(page);
  await page.setViewportSize({ width: 320, height: 680 });
  await expect.poll(() => page.locator('#view').evaluate(canvas => canvas.width)).toBeGreaterThan(0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  const box = await page.locator('#view').boundingBox();
  expect(box.width).toBeLessThanOrEqual(320);
  expect(box.height).toBeGreaterThanOrEqual(280);
  await page.locator('#zoomIn').click();
  await expect.poll(async () => (await state(page)).distance).toBeLessThan(700);
});

test('idle scenes stop rendering and input or motor animation resumes rendering', async ({ page }) => {
  await openModel(page);
  const renderCount = () => page.locator('#view').evaluate(canvas => Number(canvas.dataset.renderCount));
  const settle = () => page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  await settle();
  const initial = await renderCount();
  await page.waitForTimeout(250);
  expect(await renderCount()).toBe(initial);

  await page.locator('#zoomIn').click();
  await expect.poll(renderCount).toBeGreaterThan(initial);
  await settle();
  const afterInput = await renderCount();
  await page.waitForTimeout(250);
  expect(await renderCount()).toBe(afterInput);

  await page.locator('#motorBtn').click();
  await expect.poll(renderCount).toBeGreaterThan(afterInput+2);
  const animating = await renderCount();
  await expect.poll(renderCount).toBeGreaterThan(animating+2);
  await page.locator('#motorBtn').click();
  await expect.poll(async () => (await state(page)).running).toBe('false');
  await settle();
  const stopped = await renderCount();
  await page.waitForTimeout(250);
  expect(await renderCount()).toBe(stopped);
});

test('older Canvas engines without roundRect still draw the model', async ({ page }) => {
  await page.addInitScript(() => { CanvasRenderingContext2D.prototype.roundRect = undefined; });
  await openModel(page);
});

test('missing Canvas context shows an understandable error and logs it', async ({ page }) => {
  const consoleErrors = [];
  page.on('console', message => { if (message.type() === 'error') consoleErrors.push(message.text()); });
  await page.addInitScript(() => { HTMLCanvasElement.prototype.getContext = () => null; });
  await page.goto('/');
  await expect(page.locator('#loadStatus')).toBeVisible();
  await expect(page.locator('#loadStatus')).toContainText(/tarayıcı|Canvas|başlatılamadı|yüklenemedi/i);
  await expect.poll(() => consoleErrors.length).toBeGreaterThan(0);
});

test('render failures replace loading with an actionable message', async ({ page }) => {
  const consoleErrors = [];
  page.on('console', message => { if (message.type() === 'error') consoleErrors.push(message.text()); });
  await page.addInitScript(() => {
    CanvasRenderingContext2D.prototype.fillRect = () => { throw new Error('TEST: drawing unavailable'); };
  });
  await page.goto('/');
  await expect(page.locator('#loadStatus')).toBeVisible();
  await expect(page.locator('#loadStatus')).toContainText(/hata|başlatılamadı|yüklenemedi/i);
  await expect.poll(() => consoleErrors.length).toBeGreaterThan(0);
});

test('a failed script download leaves recovery instructions visible', async ({ page }) => {
  await page.route('**/model.js', route => route.abort('failed'));
  await page.goto('/');
  await expect(page.locator('#loadStatus')).toBeVisible();
  await expect(page.locator('#loadStatus')).toContainText(/açılamadı|yüklenemedi|hata/i);
  await expect(page.locator('#loadStatus')).toContainText(/Safari|Chrome/);
  await expect(page.locator('#retry')).toBeVisible();
});

test('JavaScript-disabled file previews show instructions instead of a blank canvas', async ({ browser, baseURL }) => {
  const context = await browser.newContext({ javaScriptEnabled: false });
  const page = await context.newPage();
  await page.goto(baseURL);
  // <noscript> itself has no layout box; its rendered message must be visible.
  const message = page.locator('noscript .load-status');
  await expect(message).toBeVisible();
  await expect(message).toContainText(/JavaScript/);
  await expect(message).toContainText(/Safari|Chrome|tarayıcı/);
  await context.close();
});

test('Android Chromium handles native simultaneous touch points', async ({ page, browserName }, testInfo) => {
  test.skip(testInfo.project.name !== 'android-chromium' || browserName !== 'chromium', 'CDP multi-touch is Chromium-only.');
  await openModel(page);
  const session = await page.context().newCDPSession(page);
  const { x, y } = await gesturePoints(page);
  const before = await state(page);
  const touch = (id, offset) => ({ x: x+offset, y, id, radiusX: 5, radiusY: 5 });
  await session.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [touch(1,-35),touch(2,35)] });
  await session.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [touch(1,-65),touch(2,65)] });
  await session.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await expect.poll(async () => (await state(page)).distance).toBeLessThan(before.distance);
  expect((await state(page)).selected).toBe(before.selected);
  await session.detach();
});
