import { mkdir, copyFile } from "node:fs/promises";
const root = new URL("../", import.meta.url);
await mkdir(new URL("dist/", root), { recursive: true });
for (const file of ["index.html", "styles.css", "model.js"]) {
  await copyFile(new URL(file, root), new URL(`dist/${file}`, root));
}
console.log(
  "Statik site hazır: dist/ (CDN veya çalışma zamanı bağımlılığı yok)",
);
