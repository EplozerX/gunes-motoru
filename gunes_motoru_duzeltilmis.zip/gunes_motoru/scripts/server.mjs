// Dependency-free static development server. Not a production application server.
import http from "node:http";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
const root = new URL("../", import.meta.url);
const args = process.argv.slice(2);
const option = (name, fallback) =>
  args.includes(name) ? args[args.indexOf(name) + 1] : fallback;
const host = option("--host", "0.0.0.0");
const port = Number(option("--port", process.env.PORT || "8000"));
const files = new Map([
  ["/", ["index.html", "text/html; charset=utf-8"]],
  ["/index.html", ["index.html", "text/html; charset=utf-8"]],
  ["/model.js", ["model.js", "text/javascript; charset=utf-8"]],
  ["/styles.css", ["styles.css", "text/css; charset=utf-8"]],
]);
const server = http.createServer(async (req, res) => {
  const path = new URL(req.url, "http://localhost").pathname;
  if (path === "/favicon.ico") {
    res.writeHead(204);
    res.end();
    return;
  }
  const file = files.get(path);
  if (!file) {
    res.writeHead(404);
    res.end("Not found");
    return;
  }
  if (!["GET", "HEAD"].includes(req.method)) {
    res.writeHead(405);
    res.end();
    return;
  }
  try {
    const data = await readFile(new URL(file[0], root));
    res.writeHead(200, {
      "Content-Type": file[1],
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(req.method === "HEAD" ? undefined : data);
  } catch (error) {
    console.error(error);
    res.writeHead(500);
    res.end("Dosya okunamadı.");
  }
});
server.on("error", (error) => {
  console.error("Sunucu başlatılamadı:", error.message);
  process.exitCode = 1;
});
server.listen(port, host, () =>
  console.log(
    `Güneş motoru: http://localhost:${port}\nKlasör: ${fileURLToPath(root)}`,
  ),
);
