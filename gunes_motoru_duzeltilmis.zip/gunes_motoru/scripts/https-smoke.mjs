// Local HTTPS transport check; not evidence of public hosting or physical-device QA.
import https from "node:https";
import { mkdtemp, readFile, rm, mkdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { execFileSync } from "node:child_process";
import { chromium, webkit, devices } from "playwright";

const root = new URL("../", import.meta.url);
const temporary = await mkdtemp(join(tmpdir(), "motor-https-"));
const key = join(temporary, "key.pem"),
  cert = join(temporary, "cert.pem");
let server;
const results = [];
try {
  execFileSync(
    "openssl",
    [
      "req",
      "-x509",
      "-newkey",
      "rsa:2048",
      "-nodes",
      "-keyout",
      key,
      "-out",
      cert,
      "-days",
      "1",
      "-subj",
      "/CN=localhost",
    ],
    { stdio: "ignore" },
  );
  const files = {
    "/": ["index.html", "text/html"],
    "/model.js": ["model.js", "text/javascript"],
    "/styles.css": ["styles.css", "text/css"],
  };
  server = https.createServer(
    { key: await readFile(key), cert: await readFile(cert) },
    async (req, res) => {
      const file = files[new URL(req.url, "https://localhost").pathname];
      if (!file) {
        res.writeHead(404);
        res.end();
        return;
      }
      try {
        res.writeHead(200, { "Content-Type": `${file[1]}; charset=utf-8` });
        res.end(await readFile(new URL(`dist/${file[0]}`, root)));
      } catch (error) {
        res.writeHead(500);
        res.end(String(error));
      }
    },
  );
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const url = `https://127.0.0.1:${server.address().port}`;
  for (const [name, type, profile] of [
    ["desktop-chromium", chromium, devices["Desktop Chrome"]],
    ["android-chromium", chromium, devices["Pixel 7"]],
    ["iphone-webkit", webkit, devices["iPhone 13"]],
  ]) {
    const browser = await type.launch(
      type === chromium && process.env.PW_CHROMIUM_EXECUTABLE_PATH
        ? { executablePath: process.env.PW_CHROMIUM_EXECUTABLE_PATH }
        : {},
    );
    try {
      const context = await browser.newContext({
        ...profile,
        ignoreHTTPSErrors: true,
      });
      const page = await context.newPage();
      const errors = [];
      page.on("pageerror", (e) => errors.push(e.message));
      const response = await page.goto(url);
      await page.waitForFunction(
        () => document.getElementById("view").dataset.ready === "true",
      );
      const colors = await page.locator("#view").evaluate((canvas) => {
        const pixels = canvas
            .getContext("2d")
            .getImageData(0, 0, canvas.width, canvas.height).data,
          colors = new Set();
        for (let i = 0; i < pixels.length; i += 400)
          colors.add(`${pixels[i]},${pixels[i + 1]},${pixels[i + 2]}`);
        return colors.size;
      });
      const target = await page.locator("#view").evaluate((canvas) => {
        const target = JSON.parse(canvas.dataset.targets).solar,
          r = canvas.getBoundingClientRect();
        return { x: r.x + target.x, y: r.y + target.y };
      });
      if (profile.isMobile) await page.touchscreen.tap(target.x, target.y);
      else await page.mouse.click(target.x, target.y);
      await page.waitForFunction(
        () => document.getElementById("view").dataset.selected === "solar",
      );
      await page.locator("#zoomIn").click();
      await page.waitForFunction(
        () => Number(document.getElementById("view").dataset.distance) < 700,
      );
      if (response.status() !== 200 || colors <= 20 || errors.length)
        throw new Error(
          JSON.stringify({ status: response.status(), colors, errors }),
        );
      results.push({
        profile: name,
        browser: browser.version(),
        status: "passed",
        colors,
        checks: [
          "HTTPS document and local assets",
          "nonblank canvas",
          "canvas selection",
          "zoom control",
          "no page errors",
        ],
      });
    } finally {
      await browser.close();
    }
  }
  const report = {
    transport: "localhost HTTPS, temporary self-signed certificate",
    certificateValidation: "ignored for this local smoke check only",
    physicalDevicesTested: false,
    publicDeploymentTested: false,
    results,
  };
  await mkdir(new URL("verification/", root), { recursive: true });
  await writeFile(
    new URL("verification/https-smoke.json", root),
    JSON.stringify(report, null, 2) + "\n",
  );
  console.log(JSON.stringify(report, null, 2));
} finally {
  if (server) await new Promise((resolve) => server.close(resolve));
  await rm(temporary, { recursive: true, force: true });
}
